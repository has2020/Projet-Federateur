create trigger TEST_TRIGGER
    before insert
    on REVENDEUR
    for each row
BEGIN
SELECT test_sequence.nextval INTO :NEW.ID FROM dual;
END;
/

